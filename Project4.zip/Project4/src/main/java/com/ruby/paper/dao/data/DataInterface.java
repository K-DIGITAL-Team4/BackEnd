package com.ruby.paper.dao.data;

import java.util.Map;

public interface DataInterface {

	Map<String, Object> testInfo();

	Map<String, Object> driveInfo();

	Map<String, Object> vehicleInfo();

}